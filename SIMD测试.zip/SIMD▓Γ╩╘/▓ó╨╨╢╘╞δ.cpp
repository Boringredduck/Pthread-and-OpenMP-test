#include <iostream>
#include <chrono>
#include <immintrin.h>

using namespace std;
int mai3() {
    const int n = 500; // �����С
    float A[n][n];
    // ��ʼ������
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            A[i][j] = (i == j) ? 2.0 : 1.0;
        }
    }

    // ���Դ���
    const int num_runs = 200; // ���д���
    double total_duration = 0.0; // ������ʱ��
    for (int i = 0; i < num_runs; i++) {
        auto start = chrono::steady_clock::now(); // ��ʼʱ��
        {
            for (int row = 0; row < n; row++) {
                __m256 v_t = _mm256_set1_ps(A[row][row]);
                int col = row + 1;
                while ((row * n + col) % 8 != 0) {
                    // padding
                    A[row][col] = A[row][col] * 1.0 / A[row][row];
                    col++;
                }
                for (; col + 8 <= n; col += 8) {
                    __m256 v_a = _mm256_loadu_ps(&A[row][col]);
                    v_a = _mm256_div_ps(v_a, v_t);
                    _mm256_storeu_ps(&A[row][col], v_a);
                }
                for (; col < n; col++) {
                    A[row][col] = A[row][col] * 1.0 / A[row][row];
                }
                A[row][row] = 1.0;
                for (int i = row + 1; i < n; i++) {
                    __m256 v_ai_k = _mm256_set1_ps(A[i][row]);
                    col = row + 1;
                    while ((row * n + col) % 8 != 0) {
                        // padding
                        A[i][col] = A[i][col] - A[row][col] * A[i][row];
                        col++;
                    }
                    for (; col + 8 <= n; col += 8) {
                        __m256 v_ak_j = _mm256_loadu_ps(&A[row][col]);
                        __m256 v_a_i_j = _mm256_loadu_ps(&A[i][col]);
                        __m256 v_x = _mm256_mul_ps(v_ak_j, v_ai_k);
                        v_a_i_j = _mm256_sub_ps(v_a_i_j, v_x);
                        _mm256_storeu_ps(&A[i][col], v_a_i_j);
                    }
                    for (; col < n; col++) {
                        A[i][col] = A[i][col] - A[row][col] * A[i][row];
                    }
                    A[i][row] = 0.0;
                }
            }

        }
        auto end = chrono::steady_clock::now(); // ����ʱ��
        auto duration = chrono::duration_cast<chrono::milliseconds>(end - start); // ����ʱ��
        total_duration += duration.count();
    }
    double avg_duration = total_duration / num_runs;
    cout << "Matrix size: " << n << "x" << n << endl;
    cout << "Average elapsed time over " << num_runs << " runs: " << avg_duration << " milliseconds" << endl;
    return 0;
}