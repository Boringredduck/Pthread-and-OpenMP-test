#include <iostream>
#include <chrono>
#include <vector>

using namespace std;

//�ռ�ֲ����Ż�
void LU_locality_optimized(vector<vector<double>>& A) {
    int n = A.size();
    for (int k = 0; k < n; k++) {
        for (int j = k + 1; j < n; j++) {
            A[k][j] /= A[k][k];
        }
        A[k][k] = 1.0;
        for (int i = k + 1; i < n; i++) {
            double factor = A[i][k];
            for (int j = k + 1; j < n; j++) {
                A[i][j] -= factor * A[k][j];
            }
            A[i][k] = 0;
        }
    }
}
//ʱ��ֲ����Ż�
void LU_temporal_optimized(vector<vector<double>>& A) {
    int n = A.size();
    for (int k = 0; k < n; k++) {
        for (int j = k + 1; j < n; j++) {
            A[k][j] /= A[k][k];
        }
        A[k][k] = 1.0;
        for (int i = k + 1; i < n; i++) {
            double factor = A[i][k];
            for (int j = k + 1; j < n; j++) {
                A[i][j] -= factor * A[k][j];
            }
            A[i][k] = factor; // ����һ������Ŀռ����洢�м���
        }
    }
}

//ʱ�վֲ����Ż�
void LU_optimized(vector<vector<double>>& A) {
    int n = A.size();
    int block_size = 32;

    for (int k = 0; k < n; k += block_size) {
        int k_end = min(k + block_size, n);

        for (int i = k; i < k_end; i++) {
            for (int j = k_end; j < n; j++) {
                A[i][j] /= A[i][i];
            }
        }

        
        for (int i = k_end; i < n; i++) {
            for (int j = k; j < k_end; j++) {
                double tmp = A[i][j];
                for (int l = k; l < i; l++) {
                    tmp -= A[i][l] * A[l][j];
                }
                A[i][j] = tmp;
            }
        }

        for (int i = k_end; i < n; i++) {
            for (int j = k_end; j < n; j++) {
                double tmp = A[i][j];
                for (int l = k; l < k_end; l++) {
                    tmp -= A[i][l] * A[l][j];
                }
                A[i][j] = tmp;
            }
        }
    }
}



int main() {
    const int n = 2000; // �����С
    vector<vector<double>> A(n, vector<double>(n));
    // ��ʼ������
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            A[i][j] = (i == j) ? 2.0 : 1.0;
        }
    }

    // ���Դ���
    const int num_runs = 2; // ���д���
    double total_duration = 0.0; // ������ʱ��
    for (int i = 0; i < num_runs; i++) {
        auto start = chrono::steady_clock::now(); // ��ʼʱ��
        {
            LU_optimized(A); // ִ��LU�ֽ�
        }
        auto end = chrono::steady_clock::now(); // ����ʱ��
        auto duration = chrono::duration_cast<chrono::milliseconds>(end - start); // ����ʱ��
        total_duration += duration.count();
    }
    double avg_duration = total_duration / num_runs;
    cout << "Matrix size: " << n << "x" << n << endl;
    cout << "Average elapsed time over " << num_runs << " runs: " << avg_duration << " milliseconds" << endl;
    return 0;
}
