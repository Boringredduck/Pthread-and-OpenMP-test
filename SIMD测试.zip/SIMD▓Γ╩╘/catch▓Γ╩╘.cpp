#include <chrono>
#include <iostream>
#include <random>
#include <immintrin.h> 

void f_pro_cache_simd(float** A, float** B, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < i; j++) {
            B[j][i] = A[i][j];
            A[i][j] = 0; // �൱��ԭ���� A[i][k] = 0;
        }
    }
    for (int k = 0; k < n; k++) {
        __m128 vt = _mm_set1_ps(A[k][k]);
        int j;
        for (j = k + 4; j <= n; j += 4) {
            __m128 va = _mm_load_ps(&(A[k][j]));
            va = _mm_div_ps(va, vt);
            _mm_store_ps(&(A[k][j]), va);
        }
        for (; j < n; j++) {
            A[k][j] = A[k][j] * 1.0f / A[k][k];
        }
        A[k][k] = 1.0f;
        for (int i = k + 1; i < n; i++) {
            __m128 vaik = _mm_set1_ps(B[k][i]);
            for (j = k + 4; j <= n; j += 4) {
                __m128 vakj = _mm_load_ps(&(A[k][j]));
                __m128 vaij = _mm_load_ps(&(A[i][j]));
                __m128 vx = _mm_mul_ps(vakj, vaik);
                vaij = _mm_sub_ps(vaij, vx);
                _mm_store_ps(&A[i][j], vaij);
            }
            for (; j < n; j++) {
                A[i][j] = A[i][j] - A[i][k] * A[k][j];
            }
        }
    }
}

int main() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<float> dis(0.0f, 1.0f);

    const int n = 100;
    const int num_tests = 10;
    float** A = new float* [n];
    float** B = new float* [n];
    for (int i = 0; i < n; i++) {
        A[i] = new float[n];
        B[i] = new float[n];
        for (int j = 0; j < n; j++) {
            A[i][j] = dis(gen);
            B[i][j] = dis(gen);
        }
    }

    double total_time = 0.0;
    for (int i = 0; i < num_tests; i++) {
        auto start_time = std::chrono::high_resolution_clock::now();

        f_pro_cache_simd(A, B, n);

        auto end_time = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time).count();
        total_time += duration;
    }
    double avg_time = total_time / num_tests;

    std::cout << "Average runtime over " << num_tests << " tests: " << avg_time <<
        " microseconds" << std::endl;

    for (int i = 0; i < n; i++) {
        delete[] A[i];
        delete[] B[i];
    }
    delete[] A;
    delete[] B;

    return 0;
}