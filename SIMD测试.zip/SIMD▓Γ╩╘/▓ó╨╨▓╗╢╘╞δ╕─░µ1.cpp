#include <iostream>
#include <chrono>
#include <vector>
#include <immintrin.h> 
using namespace std;

void LU_SIMD(vector<vector<double>>& A) {
    int n = A.size();
    const int simd_width = 4;
    for (int k = 0; k < n; k++) {
        double* Ak = &A[k][0];
        __m256d Ak_v = _mm256_loadu_pd(Ak);
        for (int j = k + 1; j < n; j++) {
            double* Aj = &A[k][j];
            __m256d Aj_v = _mm256_loadu_pd(Aj);
            __m256d Aj_div_Ak_v = _mm256_div_pd(Aj_v, Ak_v);
            _mm256_storeu_pd(Aj, Aj_div_Ak_v);
        }
        Ak[k] = 1.0;
        for (int i = k + 1; i < n; i++) {
            double* Ai = &A[i][0];
            __m256d Ak_mul_Ai_v = _mm256_broadcast_sd(&Ak[i]);
            for (int j = k + 1; j < n; j += simd_width) {
                double* Aj = &A[k][j];
                __m256d Aj_v = _mm256_loadu_pd(Aj);
                __m256d Ai_j_v = _mm256_loadu_pd(&Ai[j]);
                __m256d Aj_mul_Ak_mul_Ai_v = _mm256_mul_pd(Ak_mul_Ai_v, Aj_v);
                __m256d Ai_j_sub_Aj_mul_Ak_mul_Ai_v = _mm256_sub_pd(Ai_j_v, Aj_mul_Ak_mul_Ai_v);
                _mm256_storeu_pd(&Ai[j], Ai_j_sub_Aj_mul_Ak_mul_Ai_v);
            }
            for (int j = k + ((n - k - 1) / simd_width) * simd_width + 1; j < n; j++) {
                Ai[j] -= Ak[i] * A[k][j];
            }
            Ak[i] = 0.0;
        }
    }
}

int main2() {
    const int n = 1000; // �����С
    vector<vector<double>> A(n, vector<double>(n));
    // ��ʼ������
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            A[i][j] = (i == j) ? 2.0 : 1.0;
        }
    }

    // ���Դ���
    const int num_runs = 20; // ���д���
    double total_duration = 0.0; // ������ʱ��
    for (int i = 0; i < num_runs; i++) {
        auto start = chrono::steady_clock::now(); // ��ʼʱ��
        {
            LU_SIMD(A); // ִ��LU�ֽ�
        }
        auto end = chrono::steady_clock::now(); // ����ʱ��
        auto duration = chrono::duration_cast<chrono::milliseconds>(end - start); // ����ʱ��
        total_duration += duration.count();
    }
    double avg_duration = total_duration / num_runs;
    cout << "Matrix size: " << n << "x" << n << endl;
    cout << "Average elapsed time over " << num_runs << " runs: " << avg_duration << " milliseconds" << endl;
    return 0;
}
