#include <iostream>
#include <chrono>
#include <vector>

using namespace std;

void LU(vector<vector<double>>& A) {
    int n = A.size();
    for (int k = 0; k < n; k++) {
        for (int j = k + 1; j < n; j++) {
            A[k][j] /= A[k][k];
        }
        A[k][k] = 1.0;
        for (int i = k + 1; i < n; i++) {
            for (int j = k + 1; j < n; j++) {
                A[i][j] -= A[i][k] * A[k][j];
            }
            A[i][k] = 0;
        }
    }
}

int main1() {
    const int n = 2000; // �����С
    vector<vector<double>> A(n, vector<double>(n));
    // ��ʼ������
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            A[i][j] = (i == j) ? 2.0 : 1.0;
        }
    }

    // ���Դ���
    const int num_runs = 1; // ���д���
    double total_duration = 0.0; // ������ʱ��
    for (int i = 0; i < num_runs; i++) {
        auto start = chrono::steady_clock::now(); // ��ʼʱ��
        {
            LU(A); // ִ��LU�ֽ�
        }
        auto end = chrono::steady_clock::now(); // ����ʱ��
        auto duration = chrono::duration_cast<chrono::milliseconds>(end - start); // ����ʱ��
        total_duration += duration.count();
    }
    double avg_duration = total_duration / num_runs;
    cout << "Matrix size: " << n << "x" << n << endl;
    cout << "Average elapsed time over " << num_runs << " runs: " << avg_duration << " milliseconds" << endl;
    return 0;
}
