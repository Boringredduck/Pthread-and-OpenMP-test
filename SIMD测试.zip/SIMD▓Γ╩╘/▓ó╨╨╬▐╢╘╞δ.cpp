#include <iostream>
#include <chrono>
#include <immintrin.h>

#include <iostream>
#include <chrono>
#include <emmintrin.h>

using namespace std;

int mai2() {
    const int n = 500; // �����С
    float A[n][n];
    // ��ʼ������
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            A[i][j] = (i == j) ? 2.0 : 1.0;
        }
    }

    // ���Դ���
    const int num_runs = 200; // ���д���
    double total_duration = 0.0; // ������ʱ��
    for (int i = 0; i < num_runs; i++) {
        auto start = chrono::steady_clock::now(); // ��ʼʱ��
        for (int row = 0; row < n; row++) {
            __m128 pivot = _mm_set_ps1(A[row][row]);
            int col;
            for (col = row + 1; col + 4 <= n; col += 4) {
                __m128 values = _mm_loadu_ps(&(A[row][col]));
                values = _mm_div_ps(values, pivot);
                _mm_storeu_ps(&(A[row][col]), values);
            }
            for (; col < n; col++) {
                A[row][col] /= A[row][row];
            }
            A[row][row] = 1.0;
            for (int i = row + 1; i < n; i++) {
                __m128 factor = _mm_set_ps1(A[i][row]);
                int j;
                for (j = row + 1; j + 4 <= n; j += 4) {
                    __m128 row_factor = _mm_loadu_ps(&(A[row][j]));
                    __m128 values = _mm_loadu_ps(&(A[i][j]));
                    values = _mm_sub_ps(values, _mm_mul_ps(row_factor, factor));
                    _mm_storeu_ps(&(A[i][j]), values);
                }
                for (; j < n; j++) {
                    A[i][j] -= A[i][row] * A[row][j];
                }
                A[i][row] = 0;
            }
        }
        auto end = chrono::steady_clock::now(); // ����ʱ��
        auto duration = chrono::duration_cast<chrono::milliseconds>(end - start); // ����ʱ��
        total_duration += duration.count();
    }
    double avg_duration = total_duration / num_runs;
    cout << "Matrix size: " << n << "x" << n << endl;
    cout << "Average elapsed time over " << num_runs << " runs: " << avg_duration << " milliseconds" << endl;
    return 0;
}

